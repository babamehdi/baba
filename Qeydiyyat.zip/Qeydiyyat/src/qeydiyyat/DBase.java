/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qeydiyyat;

import com.mysql.cj.jdbc.Driver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import jdk.nashorn.internal.ir.TryNode;

/**
 *
 * @author ssd
 */
public class DBase {
    Connection con;
    Statement st;
    
   public void connect(){
  
       try {
           
           DriverManager.registerDriver(new Driver());
           con=DriverManager.getConnection("jdbc:mysql://localhost:3305/telebe?zeroDateTimeBehavior=convertToNull", "root","root");
           st=con.createStatement();
           System.out.println("Connect");
       } catch (Exception e) {
           System.out.println("NotConnect");
       }
   
   
   }
   
   public ArrayList<DGetSet> select(){
       try {
           ArrayList<DGetSet>  list=new ArrayList<DGetSet>();
           connect();
           String sql="select * from telebe.cust;";
           
           ResultSet rs=st.executeQuery(sql);
           DGetSet dg;
           while(rs.next()){
               dg=new DGetSet(rs.getInt("ID"),rs.getString("FirsName"),rs.getString("LastName"),rs.getString("Login"));
               list.add(dg);
           }
           return list;
           
           
       } catch (Exception e) {
           System.out.println("notselect");
           return null;
       }finally{
           close();
       }
   }
   
   
   public void close(){
       try {
           st.close();
           con.close();
       } catch (Exception e) {
       }
   }
   public void update(DGetSet gs){
       try {
          connect();
          String sql=" UPDATE telebe.cust SET FirsName ='"+gs.getFirstName()+"', LastName = '"+gs.getLastName()+"',Login='"+gs.getLogin()+"' WHERE ID="+gs.getID()+";";
          st.executeUpdate(sql);
           System.out.println("update");
       } catch (Exception e) {
           System.out.println("NotUpdate");
       }finally{
           close();
       }
  
   }
   
   public void insert(DGetSet gs){
       try {
           connect();
           
           String sql="insert into telebe.cust(FirsName,LastName,Login) values ('"+gs.getFirstName()+"','"+gs.getLastName()+"','"+gs.getLogin()+"');";
           st.executeUpdate(sql);
           System.out.println("insert");
       } catch (Exception e) {
           System.out.println("not");
           e.printStackTrace();
       }finally{
           close();
       }
   }
     public boolean select(DGetSet gs){
       try {
           
           connect();
           String sql="select * from telebe.cust where Login='"+gs.getLogin()+"';";
           
           ResultSet rs=st.executeQuery(sql);
           return rs.next();
          
            } catch (Exception e) {
                
           System.out.println("not");
           e.printStackTrace();
           return false;
       }finally{
           close();
       }
     
     
     }
           
    public static void main(String[] args) {
        DBase db=new DBase();
        DGetSet g=new DGetSet();
        g.setLogin("1234");
        System.out.println(db.select(g));
    }
   
    
}
