package qeydiyyat;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ssd
 */
public class DGetSet {
    private int ID;
    private String FirstName;
    private String LastName;
    private String Login;

    public DGetSet() {
    }

    public DGetSet(int ID, String FirstName, String LastName, String Login) {
        this.ID = ID;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Login = Login;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getLogin() {
        return Login;
    }

    public void setLogin(String Login) {
        this.Login = Login;
    }
    
    
    
    
}
